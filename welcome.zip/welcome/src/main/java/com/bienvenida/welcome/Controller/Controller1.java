package com.bienvenida.welcome.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class Controller1 {

    @GetMapping("/saludo")
    public String saludar(Model model) {
        LocalDateTime fechaHoraActual = LocalDateTime.now();

        DateTimeFormatter formateadorFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formateadorHora = DateTimeFormatter.ofPattern("HH:mm:ss");

        String fecha = fechaHoraActual.format(formateadorFecha);
        String hora = fechaHoraActual.format(formateadorHora);

        model.addAttribute("fecha", fecha);
        model.addAttribute("hora", hora);

        return "saludo";
    }
}